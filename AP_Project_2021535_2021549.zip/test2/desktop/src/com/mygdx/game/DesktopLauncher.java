package com.mygdx.game;

import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;
import com.mygdx.game.helpers.GameInfo;

public class DesktopLauncher {
	public static void main (String[] arg) { //Desktop launcher launches the game by creating the MyGdxGame here
		Lwjgl3ApplicationConfiguration config = new Lwjgl3ApplicationConfiguration();
		config.setForegroundFPS(60);
		config.setWindowedMode(GameInfo.WIDTH,GameInfo.HEIGHT); //Size for the entire window which shows up on running the game
		config.useVsync(true);
		config.setTitle("My GDX Game");
		new Lwjgl3Application(new MyGdxGame(), config);
	}
}

