//package com.mygdx.game;
//
//import com.badlogic.gdx.physics.box2d.World;
//
//public class Tank3 extends Tank{
//    private WeaponNapalm specialAttack;
//
//    public Tank3(World world, String name, float x, float y) {
//        super(world, name, x, y);
//    }
//}
