package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.physics.box2d.*;
import com.mygdx.game.helpers.GameInfo;

public class Tank extends Sprite implements tank_functionality {
    private World world; //Actual physics world in which the player exists--->only 1 world will be there
    private Body body;   //Body of the player(body can have mass,friction,etc)
    private int health;
    private String tankName;


    public Tank(World world,String name,float x,float y){ //(x,y) is the position
        super(new Texture(name));
        this.world=world;
        setPosition(x-getWidth()/2,y-getHeight()/2);
        createBody(); //IMPORTANT TO CALL THIS METHOD
    }
    public void createBody(){ //Here create all the components
        BodyDef bodyDef=new BodyDef(); //Body definition
        //a static body is not affected by gravity or other forces
        //a kinematic body is not affected by gravity but it is affected by other forces
        //a dynamic body is affected by gravity as well as other forces

        bodyDef.type=BodyDef.BodyType.DynamicBody;
        bodyDef.position.set(getX()/ GameInfo.PPM,getY()/GameInfo.PPM); //getX and getY is of the player(we have this method because we extended the sprite class)
        body=world.createBody(bodyDef);// world creates a body with the def defined on the body

        PolygonShape shape=new PolygonShape();
        shape.setAsBox((getWidth()/2)/GameInfo.PPM,(getHeight()/2)/GameInfo.PPM); //Will create a box just of the player
//DIVIDE BY PPM HERE!!
        FixtureDef fixtureDef=new FixtureDef();//going to define shape of the body/mass
        fixtureDef.shape=shape;
        fixtureDef.density=1;
        Fixture fixture=body.createFixture(fixtureDef);
        fixture.setUserData("Player"); //Useful for detecting which body is having contact with another
        shape.dispose();

    }
    public void updatePlayer(){ //update the player position accd to the player's body
        this.setPosition(body.getPosition().x*GameInfo.PPM,body.getPosition().y* GameInfo.PPM); //MULTIPLY BY PPM HERE!!
    }
    public Body getBody(){
        return this.body;
    }



}
