package com.mygdx.game;

public class WeaponVulcano extends Weapon{
    //code
}
