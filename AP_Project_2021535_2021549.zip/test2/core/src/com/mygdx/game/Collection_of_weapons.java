package com.mygdx.game;

public class Collection_of_weapons implements Container {

    public String weapons[]={"Weapon1","Weapon2","Weapon3"};

    @Override
    public Iterator getIterator() {
        return null;
    }
}
