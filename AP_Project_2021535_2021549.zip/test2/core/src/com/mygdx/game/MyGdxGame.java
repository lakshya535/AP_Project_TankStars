package com.mygdx.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.mygdx.game.screens.MainMenu;

import java.io.Serializable;

//extends game instead of ApplicationAdapter
//The only use of this clas is to reference to SpriteBatch and change scene(here screen)
public class MyGdxGame extends Game implements Serializable {  //MAIN CLASS--->first class to be run(inside core)
	private SpriteBatch batch; //main component for drawing things on the screen
	//Only have 1 spritebatch else game can crash
	//In order to have one,we will pass this to screen(everything we see in our screen is modelled as a screen)
	@Override //We will initialize everything here
	public void create () {  //create method is the first one to be called
		batch=new SpriteBatch();
		setScreen(new MainMenu(this)); //this refers to the class itself
	}

	//Higher fps means that the object moves faster when adding +4 to the x/y coordinate.
//30 fps means that the render method is being called 30 times per second(here every sec 30*4=120 pixel covered per sec vs 60*4=240 when fps is 60)

	@Override //render method is being called for every frame
	public void render () {
		super.render(); //It will call the render method of all our classes implementing Screen(here,such as MainGameScreen)
	}


	public SpriteBatch getBatch() {
		return batch;
	}
}

