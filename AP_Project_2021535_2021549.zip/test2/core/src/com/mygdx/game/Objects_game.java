package com.mygdx.game;

public abstract class Objects_game {
    private String name;

    public String getName() {
        return name;
    }
}
