package com.mygdx.game;

import com.badlogic.gdx.physics.box2d.Body;

public interface tank_functionality {
    void createBody();
    void updatePlayer();
    Body getBody();

}
