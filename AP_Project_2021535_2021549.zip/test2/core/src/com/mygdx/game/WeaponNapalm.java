package com.mygdx.game;

public class WeaponNapalm extends Weapon{
    //
}
