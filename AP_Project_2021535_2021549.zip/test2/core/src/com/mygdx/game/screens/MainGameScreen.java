package com.mygdx.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.BattleField;
import com.mygdx.game.MyGdxGame;
import com.mygdx.game.Tank;
import com.mygdx.game.helpers.GameInfo;
import com.mygdx.game.helpers.GameSingleton;
import com.mygdx.game.huds.UI;

import java.io.Serializable;

public class MainGameScreen implements Screen, ContactListener, Serializable {
    private Texture bg;
    private Tank tank1;
    private Tank tank2;

    public BitmapFont font;
    float x,y;
    private World world;
    private OrthographicCamera box2DCamera;
    private Viewport gameViewport;
    private Box2DDebugRenderer debugRenderer;
    private MyGdxGame game;
    private UI hud;
    BattleField bf;

//    Weapon[] weapons =new Weapon[3];
////    Iterator iterator = weapons.createIterator();
//
//    Collection c = new ArrayList();
//    for(int i=0; i < 10; i++) {
//        c.add(i);
//    }
//    Iterator iter = c.iterator();
//    while (iter.hasNext())
//        System.out.println(iter.next());
//    }

    public MainGameScreen(MyGdxGame game){
        this.game=game;
        box2DCamera=new OrthographicCamera();
        box2DCamera.setToOrtho(false,GameInfo.WIDTH/GameInfo.PPM,GameInfo.HEIGHT/GameInfo.PPM); //Camera shows what we see in the screen
        box2DCamera.position.set(GameInfo.WIDTH/2f,GameInfo.HEIGHT/2f,0); //We are going to get the centre of the screen(z-axis=0 since 2D game)

        gameViewport=new StretchViewport(GameInfo.WIDTH,GameInfo.HEIGHT,box2DCamera); //This viewport is going to stretch any screen

        debugRenderer=new Box2DDebugRenderer();
        hud=new UI(game);

        world=new World(new Vector2(0,-9.8f),true); //0 gravity in x coordinate //Allow body in world to sleep(when set to true) when we are doing nothing to that body

        world.setContactListener(this);

        bg = new Texture("Backgrounds/bg2.png");

        tank1=new Tank(world,"ta3.png",GameInfo.WIDTH/2-325,GameInfo.HEIGHT/2-10);
        tank2=new Tank(world,"ta3_rev.png",GameInfo.WIDTH/2+325,GameInfo.HEIGHT/2-10);


        //1 pixel=1 metre (PIXEL per METRE-->PPM) by default(box2D)
        //But we want it to be 100 pixels=1 metre
        bf=new BattleField(world);
    }



    @Override //Initialize everything you want in the show method
    public void show() { //Same as create--first method which will be called when MainGameScreen object is created
        font=new BitmapFont();
    }

    //Forces act on the body to move it left or right
    void update(float dt){
        if(!GameSingleton.getInstance().isPaused) {
            if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
                tank1.getBody().applyForce(new Vector2(-5f, 0), tank1.getBody().getWorldCenter(), true); //Apply -1 force for x coordinate(no effect on the y-coordinate) and apply the force at the centre point of the body(to avoid torque,etc)
            } //setting true ensures that if the body was asleep,the force would wake it up //Linear Impulse moves it as soon we press the key
            if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
                tank1.getBody().applyForce(new Vector2(5f, 0), tank1.getBody().getWorldCenter(), true);
            }
            if (Gdx.input.isKeyPressed(Input.Keys.A)) {
                tank2.getBody().applyForce(new Vector2(-5f, 0), tank2.getBody().getWorldCenter(), true); //Apply -1 force for x coordinate(no effect on the y-coordinate) and apply the force at the centre point of the body(to avoid torque,etc)
            } //setting true ensures that if the body was asleep,the force would wake it up //Linear Impulse moves it as soon we press the key
            if (Gdx.input.isKeyPressed(Input.Keys.D)) {
                tank2.getBody().applyForce(new Vector2(5f, 0), tank2.getBody().getWorldCenter(), true);
            }
        }

    }


    @Override
    public void render(float delta) {
        update(delta);
        tank1.updatePlayer(); //update tank1 accd to its body
        tank2.updatePlayer();

        ScreenUtils.clear(1, 0, 0, 1); //Using rgb values, a: is alpha(a=0 means transparent else if a=1-->visible)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT); //Will remove everything on the screen

        game.getBatch().begin();//Need to call begin function before we draw something on the screen
        game.getBatch().draw(bg, x, y+65); //(0,0) is the bottom left corner
        game.getBatch().draw(tank1,tank1.getX(),tank1.getY()-tank1.getHeight()/2f );
        game.getBatch().draw(tank2,tank2.getX(),tank2.getY()-tank2.getHeight()/2f );

        game.getBatch().draw(bf,bf.getX(),bf.getY());

        game.getBatch().end();//End after draw function is called
        debugRenderer.render(world,box2DCamera.combined); //projection matrix of the camera is what is displayed to us
        game.getBatch().setProjectionMatrix(gameViewport.getCamera().combined);
        game.getBatch().setProjectionMatrix(hud.getStage().getCamera().combined);
        hud.getStage().draw();
        world.step(Gdx.graphics.getDeltaTime(),6,2 );//how many times to calculate physics(timestep)
    }

    @Override
    public void resize(int width, int height) {
        gameViewport.update(GameInfo.WIDTH,GameInfo.HEIGHT);
    }

    @Override //when pause our game
    public void pause() {

    }

    @Override //resume the game(start counting the score in the game now)
    public void resume() {

    }

    @Override //bring the application to the background
    public void hide() {

    }

    @Override //called when we terminate our application-->dispose off all of our methods
    public void dispose() { //
        bg.dispose();
        tank1.getTexture().dispose();
        tank2.getTexture().dispose();
    }


    @Override
    public void beginContact(Contact contact) {

    }

    @Override
    public void endContact(Contact contact) {

    }

    @Override
    public void preSolve(Contact contact, Manifold oldManifold) {

    }

    @Override
    public void postSolve(Contact contact, ContactImpulse impulse) {

    }
}
