package com.mygdx.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.MyGdxGame;
import com.mygdx.game.helpers.GameInfo;
import com.mygdx.game.huds.MainMenuButtons;

public class MainMenu implements Screen {
    private MyGdxGame game;
    private OrthographicCamera mainCamera;
    private Viewport gameViewport;
    private Texture bg;
    private MainMenuButtons btns;


    public MainMenu(MyGdxGame game){
        this.game=game;
        mainCamera=new OrthographicCamera();
        mainCamera.setToOrtho(false, GameInfo.WIDTH, GameInfo.HEIGHT);
        mainCamera.position.set(GameInfo.WIDTH/2f,GameInfo.HEIGHT/2f,0);
        gameViewport=new StretchViewport(GameInfo.WIDTH,GameInfo.HEIGHT,mainCamera);

        bg=new Texture("Backgrounds/ReTank.png");
        btns=new MainMenuButtons(game);
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(1, 0, 0, 1); //Using rgb values, a: is alpha(a=0 means transparent else if a=1-->visible)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT); //Will remove everything on the screen
        game.getBatch().begin();
        game.getBatch().draw(bg,0,0);

        game.getBatch().end();
        game.getBatch().setProjectionMatrix(btns.getStage().getCamera().combined);
        btns.getStage().draw();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        bg.dispose();
        btns.getStage().dispose();

    }
}
