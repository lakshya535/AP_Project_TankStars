package com.mygdx.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.BattleField;
import com.mygdx.game.MyGdxGame;
import com.mygdx.game.helpers.GameInfo;
import com.mygdx.game.huds.UI_hudTank;

public class ChooseTankScreen implements Screen, ContactListener {
    private Texture bg;
    public BitmapFont font;
    float x,y;
    private World world;
    private OrthographicCamera box2DCamera;
    private Viewport gameViewport;
    private Box2DDebugRenderer debugRenderer;
    private MyGdxGame game;
    private UI_hudTank hud;
    BattleField bf;

    public ChooseTankScreen(MyGdxGame game){
        this.game=game;
        box2DCamera=new OrthographicCamera();
        box2DCamera.setToOrtho(false,GameInfo.WIDTH/GameInfo.PPM,GameInfo.HEIGHT/GameInfo.PPM); //Camera shows what we see in the screen
        box2DCamera.position.set(GameInfo.WIDTH/2f,GameInfo.HEIGHT/2f,0); //We are going to get the centre of the screen(z-axis=0 since 2D game)

        gameViewport=new StretchViewport(GameInfo.WIDTH,GameInfo.HEIGHT,box2DCamera); //This viewport is going to stretch any screen

        debugRenderer=new Box2DDebugRenderer();
        hud=new UI_hudTank(game);

        world=new World(new Vector2(0,-9.8f),true); //0 gravity in x coordinate //Allow body in world to sleep(when set to true) when we are doing nothing to that body

        world.setContactListener(this);

        bg = new Texture("Backgrounds/choosebg.png");
    }



    @Override
    public void show() {
        font=new BitmapFont();
    }

    void update(float dt){

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(1, 0, 0, 1); //Using rgb values, a: is alpha(a=0 means transparent else if a=1-->visible)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT); //Will remove everything on the screen

        game.getBatch().begin();//Need to call begin function before we draw something on the screen
        game.getBatch().draw(bg, x, y); //(0,0) is the bottom left corner
        game.getBatch().end();//End after draw function is called
        debugRenderer.render(world,box2DCamera.combined); //projection matrix of the camera is what is displayed to us
        game.getBatch().setProjectionMatrix(gameViewport.getCamera().combined);
        game.getBatch().setProjectionMatrix(hud.getStage().getCamera().combined);
        hud.getStage().draw();
        world.step(Gdx.graphics.getDeltaTime(),6,2 );//how many times to calculate physics(timestep)
    }

    @Override
    public void resize(int width, int height) {
        gameViewport.update(GameInfo.WIDTH,GameInfo.HEIGHT);
    }

    @Override //when pause our game
    public void pause() {

    }

    @Override //resume the game(start counting the score in the game now)
    public void resume() {

    }

    @Override //bring the application to the background
    public void hide() {

    }

    @Override //called when we terminate our application-->dispose off all of our methods
    public void dispose() { //
        bg.dispose();
    }


    @Override
    public void beginContact(Contact contact) {

    }

    @Override
    public void endContact(Contact contact) {

    }

    @Override
    public void preSolve(Contact contact, Manifold oldManifold) {

    }

    @Override
    public void postSolve(Contact contact, ContactImpulse impulse) {

    }
}
