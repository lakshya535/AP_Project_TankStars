package com.mygdx.game;

public class Airdrops extends Objects_game{
    private float x_airdrop;
    private float y_airdrop;


    public float getX_airdrop() {
        return x_airdrop;
    }

    public float getY_airdrop() {
        return y_airdrop;
    }
}
