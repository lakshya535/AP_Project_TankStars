package com.mygdx.game;

import com.badlogic.gdx.physics.box2d.World;

public class Tank2 extends Tank{
    private WeaponAirStrike specialAttack;

    public Tank2(World world, String name, float x, float y) {
        super(world, name, x, y);
    }
}
