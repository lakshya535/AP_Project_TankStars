package com.mygdx.game.huds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.SpriteDrawable;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.MyGdxGame;
import com.mygdx.game.helpers.GameInfo;
import com.mygdx.game.screens.MainGameScreen;

public class UI_hudTank {
    private MyGdxGame game;
    private Stage stage;
    private Viewport gameViewport;

    private Image tank1Img,tank2Img,tank3Img; //photo

    private ImageButton tank1Btn,tank2Btn,tank3Btn; //button to pause the game

    public UI_hudTank(MyGdxGame game){
        this.game=game;
        gameViewport=new FitViewport(GameInfo.WIDTH,GameInfo.HEIGHT,new OrthographicCamera());
        stage=new Stage(gameViewport,game.getBatch());
        Gdx.input.setInputProcessor(stage);


        tank1Img=new Image(new Texture("ta3n.png"));
        tank2Img=new Image(new Texture("ta3n.png"));
        tank3Img=new Image(new Texture("ta3n.png"));

        Table table1=new Table();

        table1.center();

        table1.setFillParent(true);

        table1.add(tank1Img).padRight(70).padBottom(200);
        table1.add(tank2Img).padLeft(40).padBottom(200);
        table1.add(tank3Img).padLeft(80).padBottom(200);
        table1.row();

        getStage().addActor(table1);

        createTankBtn();


    }

    void createTankBtn(){

        tank1Btn=new ImageButton(new SpriteDrawable(new Sprite(new Texture("tan1.png"))));
        tank1Btn.setPosition(GameInfo.WIDTH/2f-240,GameInfo.HEIGHT/2f-10,Align.center);

        tank2Btn=new ImageButton(new SpriteDrawable(new Sprite(new Texture("tan2.png"))));
        tank2Btn.setPosition(GameInfo.WIDTH/2f,GameInfo.HEIGHT/2f-10,Align.center);

        tank3Btn=new ImageButton(new SpriteDrawable(new Sprite(new Texture("tan3.png"))));
        tank3Btn.setPosition(GameInfo.WIDTH/2f+240,GameInfo.HEIGHT/2f-10,Align.center);

        tank1Btn.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new MainGameScreen(game));
            }
        });

        tank2Btn.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new MainGameScreen(game));
            }
        });

        tank3Btn.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new MainGameScreen(game));
            }
        });


        getStage().addActor(tank1Btn);
        getStage().addActor(tank2Btn);
        getStage().addActor(tank3Btn);
    }


    public Stage getStage() {
        return stage;
    }
}
