package com.mygdx.game.huds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.SpriteDrawable;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.MyGdxGame;
import com.mygdx.game.helpers.GameInfo;
import com.mygdx.game.screens.ChooseTankScreen;

public class MainMenuButtons {
    private MyGdxGame game;
    private Stage stage; //just like a screen
    private Viewport gameViewport;

    private ImageButton playBtn;
    private ImageButton resumeBtn;
    private ImageButton quitBtn;

    public MainMenuButtons(MyGdxGame game){
        this.game=game;

        gameViewport=new FitViewport(GameInfo.WIDTH,GameInfo.HEIGHT,new OrthographicCamera());
        stage=new Stage(gameViewport,game.getBatch());
        Gdx.input.setInputProcessor(stage);//stage is the one which register when button is pressed


        playBtn=new ImageButton(new SpriteDrawable(new Sprite(new Texture("Start.png"))));
        resumeBtn=new ImageButton(new SpriteDrawable(new Sprite(new Texture("Resume.png"))));
        quitBtn=new ImageButton(new SpriteDrawable(new Sprite(new Texture("Quit.png"))));


        playBtn.setPosition(GameInfo.WIDTH/2f+220,GameInfo.HEIGHT/2f+100, Align.center);
        resumeBtn.setPosition(GameInfo.WIDTH/2f+220,GameInfo.HEIGHT/2f+25, Align.center);
        quitBtn.setPosition(GameInfo.WIDTH/2f+220,GameInfo.HEIGHT/2f-50, Align.center);

        addAllListeners(); //to add those listeners to our buttons
        stage.addActor(playBtn);
        stage.addActor(resumeBtn);
        stage.addActor(quitBtn);


    }

    void addAllListeners(){
        playBtn.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) { //write the code that will be executed on pressing the play button
                game.setScreen(new ChooseTankScreen(game));
            }
        });

        quitBtn.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) { //write the code that will be executed on pressing the play button
                Gdx.app.exit();
                System.exit(-1);
            }
        });
    }

    public Stage getStage(){
        return this.stage;
    }



}
