package com.mygdx.game.huds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.SpriteDrawable;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.MyGdxGame;
import com.mygdx.game.helpers.GameInfo;
import com.mygdx.game.screens.MainMenu;

public class UI {
    private MyGdxGame game;
    private Stage stage;
    private Viewport gameViewport;

    private Image tankImg,tank2Img,pausePanel,SelectPower,SelectAngle,fire,fuel1Img,fuel2Img; //photo for coin,...

    private Label health1Label,health2Label,powerLabel,angleLabel,fuel1Label,fuel2Label; //Display the number of coins,...to the user
    private ImageButton pauseBtn,resumeBtn,saveBtn,quitBtn,fireBtn; //button to pause the game

    public UI(MyGdxGame game){
        this.game=game;
        gameViewport=new FitViewport(GameInfo.WIDTH,GameInfo.HEIGHT,new OrthographicCamera());
        stage=new Stage(gameViewport,game.getBatch());
        Gdx.input.setInputProcessor(stage); //When we don't get a response from a button,##CHECK THIS!!

        FreeTypeFontGenerator generator=new FreeTypeFontGenerator(Gdx.files.internal("blow.ttf"));
        FreeTypeFontGenerator.FreeTypeFontParameter parameter=new FreeTypeFontGenerator.FreeTypeFontParameter();
        parameter.size=38;
        BitmapFont font=generator.generateFont(parameter);
        health1Label=new Label("100",new Label.LabelStyle(font, Color.WHITE));
        health2Label=new Label("100",new Label.LabelStyle(font, Color.WHITE));
        powerLabel=new Label("0",new Label.LabelStyle(font,Color.WHITE));
        angleLabel=new Label("0",new Label.LabelStyle(font,Color.WHITE));
        fuel1Label=new Label("20",new Label.LabelStyle(font,Color.WHITE));
        fuel2Label=new Label("20",new Label.LabelStyle(font,Color.WHITE));


        tankImg=new Image(new Texture("tank_img.png"));
        tank2Img=new Image(new Texture("tank2_img.png"));
        SelectPower=new Image(new Texture("sp.png"));
        SelectAngle=new Image(new Texture("sa.png"));
        fire=new Image(new Texture("fire.png"));
        fuel1Img=new Image(new Texture("fuel.png"));
        fuel2Img=new Image(new Texture("fuel.png"));


        Table table1=new Table();
        Table table2=new Table();
        Table table3=new Table();

        table1.top().left();
        table1.setFillParent(true);

        table1.add(tankImg).padLeft(10).padTop(10);
        table1.add(health1Label).padLeft(25).padTop(10);
        table1.row();
        table1.add(fuel1Img).padLeft(10).padTop(10);
        table1.add(fuel1Label).padLeft(10).padTop(10);


        table2.top().right();
        table2.setFillParent(true);

        table2.add(health2Label).padLeft(20).padTop(10);
        table2.add(tank2Img).padLeft(20).padTop(10);
        table2.row();
        table2.add(fuel2Label).padRight(-30).padTop(10);
        table2.add(fuel2Img).padRight(-30).padTop(10);

        table3.bottom().left();
        table3.setFillParent(true);

        table3.add(SelectPower).padLeft(20).padBottom(10);
        table3.add(powerLabel).padLeft(20).padBottom(10);
        table3.add(SelectAngle).padLeft(50).padBottom(10);
        table3.add(angleLabel).padLeft(20).padBottom(10);
        table3.add(fire).padLeft(50).padBottom(10);

        getStage().addActor(table1);
        getStage().addActor(table2);
        getStage().addActor(table3);


        pauseBtn=new ImageButton(new SpriteDrawable(new Sprite(new Texture("pause.png"))));
        pauseBtn.setPosition(780,10, Align.bottomRight);
        pauseBtn.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                createPausePanel();
            }
        });
        getStage().addActor(pauseBtn);

    }


    void createPausePanel(){
        pausePanel=new Image(new Texture("Pause_screen.png"));
        pausePanel.setPosition(GameInfo.WIDTH/2f,GameInfo.HEIGHT/2f,Align.center); //IMP. TO ALIGN IN CENTRE(CHECK THIS)

        saveBtn=new ImageButton(new SpriteDrawable(new Sprite(new Texture("saveGame.png"))));
        saveBtn.setPosition(GameInfo.WIDTH/2f,GameInfo.HEIGHT/2f-10,Align.center);

        resumeBtn=new ImageButton(new SpriteDrawable(new Sprite(new Texture("resumePanel.png"))));
        resumeBtn.setPosition(GameInfo.WIDTH/2f,GameInfo.HEIGHT/2f+80,Align.center);

        quitBtn=new ImageButton(new SpriteDrawable(new Sprite(new Texture("exit.png"))));
        quitBtn.setPosition(GameInfo.WIDTH/2f,GameInfo.HEIGHT/2f-100,Align.center);

        resumeBtn.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                removePausePanel();
            }
        });

        quitBtn.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                game.setScreen(new MainMenu(game));
            }
        });


        getStage().addActor(pausePanel);
        getStage().addActor(saveBtn);
        getStage().addActor(resumeBtn);
        getStage().addActor(quitBtn);
    }

    void removePausePanel(){
        pausePanel.remove();
        resumeBtn.remove(); //remove them from the stage as actors and so not drawn on the screen
        quitBtn.remove();
        saveBtn.remove();
    }


    public Stage getStage() {
        return stage;
    }
}
