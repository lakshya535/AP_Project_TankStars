package com.mygdx.game.helpers;

public class GameInfo {
    public static final int WIDTH=800;
    public static final int HEIGHT=480;
    public static final int PPM=100;//pixels per metre
}//Game information:

//FLOW OF THE GAME:
// Desktop Launcher launches the game by creating a MyGdxGame object
//        ----->
//The create method of the MyGdxGame will be called from which a MainGameScreen object(parameter as the game) is created
//        ----->
//The render method of the MyGdxGame class will be called every frame which will redirect the render method of the MainGameScreen(of all the other screens) to get called



