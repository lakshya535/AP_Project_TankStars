package com.mygdx.game.helpers;

public class GameSingleton {
    private static GameSingleton instance =new GameSingleton();
    public boolean isPaused=false;
    public int fuel;
    public int health1;
    public int health2;

    private GameSingleton(){
    }

    public static GameSingleton getInstance(){
        return instance;
    }
}
