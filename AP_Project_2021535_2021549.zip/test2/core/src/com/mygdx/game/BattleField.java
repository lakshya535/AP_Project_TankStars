package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.physics.box2d.*;
import com.mygdx.game.helpers.GameInfo;

public class BattleField extends Sprite{

    private World world;
    private Body body;

    public BattleField(World world){
        super(new Texture("field.jpeg"));
        this.world=world;
        setPosition(0,0);
        createBody();
    }
    void createBody(){ //Similar to the way tank body was created
        BodyDef bodyDef=new BodyDef();
        bodyDef.type=BodyDef.BodyType.StaticBody;
        bodyDef.position.set(getX()/ GameInfo.PPM,getY()/GameInfo.PPM);
        body=world.createBody(bodyDef);

        PolygonShape shape=new PolygonShape();
        shape.setAsBox((getWidth())/GameInfo.PPM,(getHeight())/GameInfo.PPM);

        FixtureDef fixtureDef=new FixtureDef();
        fixtureDef.shape=shape;
        fixtureDef.density=1f;
        fixtureDef.friction=6;
        Fixture fixture=body.createFixture(fixtureDef);
        fixture.setUserData("BattleField");
        fixture.setSensor(false);
        shape.dispose();
    }
}

