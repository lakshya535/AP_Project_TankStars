package com.mygdx.game;

public class WeaponAirStrike extends Weapon{
    //code
}
