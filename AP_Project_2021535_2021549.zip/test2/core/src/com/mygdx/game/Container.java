package com.mygdx.game;

public interface Container {
    public Iterator getIterator();

}
